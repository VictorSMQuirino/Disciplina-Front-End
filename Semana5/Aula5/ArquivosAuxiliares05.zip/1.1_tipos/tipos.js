//Tipos primitivos
var cpf = 12345678900;
var endereco = "Rua dos bobos, 0";
var booleano = true;
var nulo = null;
var indefinido = undefined;
var numero = 3.14;
//Tipos Complexos
//Array
var avioesww2 = ["Spitfire", "Mustang", "Zero"];
//Object
var pessoa = { nome: "João", idade: 20 };
//cria a pessoa2 objeto
var pessoa2;
pessoa2 = {
    nome: "João",
    idade: 20
};
//Array de objetos
var Pessoas = [pessoa, pessoa2];
console.log(Pessoas);
console.log(Pessoas[0]);
console.log(Pessoas[1]);
console.log(Pessoas[0].nome);
console.log(Pessoas[0].idade);
console.log(Pessoas[1].nome);
console.log(Pessoas[1].idade);
