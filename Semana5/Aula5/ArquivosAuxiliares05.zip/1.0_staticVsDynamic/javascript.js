//Função javascript padrão
function elevaAoCubo(a){
    return a * a * a;;   
}

function somar(a, b){
    return a + b;
}

const resultado = elevaAoCubo('3');

const resultado2 = somar('3', '4');

console.log(resultado);

console.log(resultado2);