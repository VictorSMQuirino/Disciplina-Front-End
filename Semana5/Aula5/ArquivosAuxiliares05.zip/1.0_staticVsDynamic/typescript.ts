//Função javascript padrão
function elevaAoCubo2(a: number){
    return a * a * a;;   
}

function somar2(a: number, b: number){
    return a + b;
}

const resultado_ = elevaAoCubo2(3);

const resultado2_ = somar2(3, 4);

console.log(resultado_);

console.log(resultado2_);