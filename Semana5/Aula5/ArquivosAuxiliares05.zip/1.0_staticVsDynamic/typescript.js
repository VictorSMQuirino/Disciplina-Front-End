//Função javascript padrão
function elevaAoCubo2(a) {
    return a * a * a;
    ;
}
function somar2(a, b) {
    return a + b;
}
var resultado_ = elevaAoCubo2(3);
var resultado2_ = somar2(3, 4);
console.log(resultado_);
console.log(resultado2_);
